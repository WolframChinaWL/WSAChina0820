from wolframclient.evaluation import WolframLanguageSession
from wolframclient.language import wl, wlexpr, Global
from itertools import permutations


for i in permutations(range(13)):
    if i[0] == 0:
        print(i)
